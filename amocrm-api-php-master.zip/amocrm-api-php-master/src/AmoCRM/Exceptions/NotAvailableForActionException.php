<?php

namespace AmoCRM\Exceptions;

class NotAvailableForActionException extends AmoCRMApiException
{
}
