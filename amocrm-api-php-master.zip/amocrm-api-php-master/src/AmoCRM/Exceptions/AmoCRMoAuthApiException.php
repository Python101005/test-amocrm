<?php

namespace AmoCRM\Exceptions;

/**
 * Class AmoCRMoAuthApiException
 *
 * Выбрасывается в случае ошибики при работе с oAuth amoCRM
 *
 * @package AmoCRM\Exceptions
 */
class AmoCRMoAuthApiException extends AmoCRMApiException
{
}
