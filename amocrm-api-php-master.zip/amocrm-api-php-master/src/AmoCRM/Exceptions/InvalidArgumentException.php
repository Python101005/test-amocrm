<?php

namespace AmoCRM\Exceptions;

class InvalidArgumentException extends AmoCRMApiException
{
}
