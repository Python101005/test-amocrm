<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class OrgLegalNameCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class OrgLegalNameCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
