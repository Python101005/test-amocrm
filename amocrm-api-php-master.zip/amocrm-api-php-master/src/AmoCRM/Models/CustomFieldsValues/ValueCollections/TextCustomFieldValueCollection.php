<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class TextCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class TextCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
