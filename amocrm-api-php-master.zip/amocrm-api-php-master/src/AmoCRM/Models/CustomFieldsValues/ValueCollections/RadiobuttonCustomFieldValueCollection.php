<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class RadiobuttonCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class RadiobuttonCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
