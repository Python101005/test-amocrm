<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class StreetAddressCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class StreetAddressCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
