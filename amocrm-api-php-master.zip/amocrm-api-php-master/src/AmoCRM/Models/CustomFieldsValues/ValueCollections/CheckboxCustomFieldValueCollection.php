<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class CheckboxCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class CheckboxCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
