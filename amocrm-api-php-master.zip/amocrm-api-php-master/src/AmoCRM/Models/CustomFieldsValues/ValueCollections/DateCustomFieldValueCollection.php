<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class DateCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class DateCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
