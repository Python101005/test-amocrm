<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class SelectCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class SelectCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
