<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class UrlCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class UrlCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
