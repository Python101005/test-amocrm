<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class CategoryCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class CategoryCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
