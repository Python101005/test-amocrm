<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class MultiselectCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class MultiselectCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
