<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class LegalEntityCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class LegalEntityCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
