<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class NumericCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class NumericCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
