<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class PriceCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method PriceCustomFieldValueModel fromArray($value)
 */
class PriceCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
