<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class UrlCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method UrlCustomFieldValueModel fromArray($value)
 */
class UrlCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
