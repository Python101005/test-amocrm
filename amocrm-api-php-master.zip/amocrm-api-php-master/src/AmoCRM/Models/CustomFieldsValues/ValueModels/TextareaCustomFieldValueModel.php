<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class TextareaCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method TextareaCustomFieldValueModel fromArray($value)
 */
class TextareaCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
