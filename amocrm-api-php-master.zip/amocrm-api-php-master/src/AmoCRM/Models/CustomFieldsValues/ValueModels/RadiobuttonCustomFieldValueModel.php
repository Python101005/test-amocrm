<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class RadiobuttonCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method RadiobuttonCustomFieldValueModel fromArray($value)
 */
class RadiobuttonCustomFieldValueModel extends BaseEnumCustomFieldValueModel
{

}
