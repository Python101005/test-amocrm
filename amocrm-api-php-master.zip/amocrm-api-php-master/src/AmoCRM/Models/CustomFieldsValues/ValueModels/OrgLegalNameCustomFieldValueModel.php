<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class OrgLegalNameCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method OrgLegalNameCustomFieldValueModel fromArray($value)
 */
class OrgLegalNameCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
