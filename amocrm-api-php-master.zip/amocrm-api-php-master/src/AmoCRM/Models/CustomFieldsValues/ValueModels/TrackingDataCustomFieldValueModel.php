<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class TrackingDataCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method TrackingDataCustomFieldValueModel fromArray($value)
 */
class TrackingDataCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
